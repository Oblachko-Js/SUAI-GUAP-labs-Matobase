#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ε-NFA → полный ДКА по Рейуорду-Смиту (1988, гл. 3)"""

import json
from collections import defaultdict, deque
import os
import argparse

try:
    import pydot
except ImportError:
    print("Установите pydot и graphviz: pip install pydot graphviz")
    exit(1)


def load_automaton(path: str):
    """Загрузка ε-NFA из JSON"""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    states = set(map(str, data["states"]))
    alphabet = data["alphabet"]
    start = str(data["start"])
    accept = set(map(str, data["accept"]))
    trans = defaultdict(lambda: defaultdict(list))

    for s, rules in data.get("transitions", {}).items():
        s = str(s)
        for sym, targets in rules.items():
            trans[s][sym].extend(map(str, targets))

    return {"states": states, "alphabet": alphabet, "start": start, "accept": accept, "trans": trans}


def compute_epsilon_closure(automaton):
    """Вычисление ε-замыканий R(p)"""
    trans = automaton["trans"]
    states = automaton["states"]
    closure = {}

    for state in states:
        visited = {state}
        queue = deque([state])
        while queue:
            cur = queue.popleft()
            for nxt in trans[cur].get("ε", []):
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append(nxt)
        closure[state] = frozenset(visited)
    return closure


def eliminate_epsilon(automaton, epsilon_closure):
    """Этап 1: Устранение ε-переходов (Теорема 3.6)"""
    alphabet = automaton["alphabet"]
    old_trans = automaton["trans"]
    accept = automaton["accept"]
    new_trans = defaultdict(dict)
    new_accept = set()

    for s, cl in epsilon_closure.items():
        if cl & accept:
            new_accept.add(s)

    for state in automaton["states"]:
        cl = epsilon_closure[state]
        for sym in alphabet:
            targets = set()
            for q in cl:
                targets.update(old_trans[q].get(sym, []))
            if targets:
                new_trans[state][sym] = list(targets)

    return {
        "states": automaton["states"],
        "alphabet": alphabet,
        "start": automaton["start"],
        "accept": new_accept,
        "trans": dict(new_trans)
    }


def subset_construction(nfa):
    """Этап 2: Детерминизация (Теорема 3.2)"""
    trans = nfa["trans"]
    start_set = frozenset([nfa["start"]])
    alphabet = nfa["alphabet"]
    accept = nfa["accept"]

    state_map = {}
    queue = deque([start_set])
    discovered = {start_set}
    new_trans = {}
    new_accept = set()
    counter = 0

    while queue:
        current = queue.popleft()
        name = f"q{counter}"
        state_map[current] = name
        counter += 1

        if current & accept:
            new_accept.add(name)

        new_trans[name] = {}
        for sym in alphabet:
            next_set = set()
            for s in current:
                next_set.update(trans.get(s, {}).get(sym, []))
            next_froz = frozenset(next_set)
            new_trans[name][sym] = next_froz

            if next_froz and next_froz not in discovered:
                discovered.add(next_froz)
                queue.append(next_froz)

    final_trans = {}
    for name, rules in new_trans.items():
        final_trans[name] = {sym: state_map.get(target, "∅") for sym, target in rules.items()}

    return {
        "states": list(state_map.values()),
        "alphabet": alphabet,
        "start": state_map[start_set],
        "accept": new_accept,
        "trans": final_trans,
        "raw_sets": state_map
    }


def complete_dfa(dfa):
    """Этап 3: Завершение с Δ"""
    alphabet = dfa["alphabet"]
    states = dfa["states"][:]
    trans = {s: dict(dfa["trans"].get(s, {})) for s in dfa["states"]}
    start = dfa["start"]
    accept = dfa["accept"]

    sink = "Δ"
    if sink not in states:
        states.append(sink)

    for s in states:
        for sym in alphabet:
            if sym not in trans.get(s, {}) or trans[s][sym] == "∅":
                trans.setdefault(s, {})[sym] = sink

    trans[sink] = {sym: sink for sym in alphabet}

    return {"states": states, "alphabet": alphabet, "start": start, "accept": accept, "trans": trans}


def to_dot(automaton, title="Автомат", is_dfa=False):
    """Генерация графа в Graphviz"""
    dot = pydot.Dot(title, rankdir="LR")
    dot.set_node_defaults(shape="circle", style="filled", fillcolor="white", fontsize="12")

    for s in automaton["states"]:
        shape = "doublecircle" if s in automaton["accept"] else "circle"
        fillcolor = "lightgrey" if s in automaton["accept"] else "white"
        dot.add_node(pydot.Node(s, shape=shape, fillcolor=fillcolor))

    dot.add_node(pydot.Node(automaton["start"], peripheries=2))

    for src in automaton["trans"]:
        for sym, targets in automaton["trans"][src].items():
            if isinstance(targets, str):
                targets = [targets]
            for t in targets:
                if t == "∅":
                    continue
                label = "ε" if sym == "ε" else sym
                color = "red" if is_dfa and t == "Δ" else "black"
                dot.add_edge(pydot.Edge(src, t, label=label, color=color))

    return dot


def main():
    parser = argparse.ArgumentParser(description="ε-NFA → полный ДКА (Рейуорд-Смит 1988)")
    parser.add_argument("json_file", help="JSON с автоматом")
    args = parser.parse_args()

    print(f"Загрузка: {args.json_file}")
    auto = load_automaton(args.json_file)

    print("1. Устранение ε-переходов...")
    eps_cl = compute_epsilon_closure(auto)
    nfa = eliminate_epsilon(auto, eps_cl)

    print("2. Детерминизация...")
    dfa = subset_construction(nfa)

    print("3. Завершение (Δ)...")
    full_dfa = complete_dfa(dfa)

    os.makedirs("results", exist_ok=True)
    base = os.path.splitext(os.path.basename(args.json_file))[0]

    to_dot(auto, "Исходный НКНА").write_png(f"results/{base}_nfa.png")
    to_dot(auto, "Исходный НКНА").write_dot(f"results/{base}_nfa.dot")

    to_dot(full_dfa, "Полный ДКА", is_dfa=True).write_png(f"results/{base}_full_dfa.png")
    to_dot(full_dfa, "Полный ДКА", is_dfa=True).write_dot(f"results/{base}_full_dfa.dot")

    with open(f"results/{base}_table.txt", "w", encoding="utf-8") as f:
        f.write("ПОЛНЫЙ ДКА\n")
        f.write(f"Состояний: {len(full_dfa['states'])}\n")
        f.write(f"Начальное: {full_dfa['start']}\n")
        f.write(f"Конечные: {', '.join(sorted(full_dfa['accept']))}\n\n")
        f.write("    │ " + "  ".join(full_dfa["alphabet"]) + "\n")
        f.write("────┼" + "───" * len(full_dfa["alphabet"]) + "\n")
        for s in sorted(full_dfa["states"], key=lambda x: (x != full_dfa["start"], x != "Δ", x)):
            f.write(f"{s:<3} │ " + "  ".join(full_dfa["trans"][s].get(a, "—") for a in full_dfa["alphabet"]) + "\n")

    print("ГОТОВО! Результаты в ./results/")
    print(f"Состояний: {len(full_dfa['states'])}")


if __name__ == "__main__":
    main()