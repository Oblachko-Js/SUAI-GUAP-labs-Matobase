#include <iostream>
#include <cstring>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h> // Для inet_ntop
#include <windows.h>
#include <thread>
#include <mutex>
#include <chrono>

#pragma comment(lib, "ws2_32.lib") // Подключение библиотеки Winsock

#define MAX_CLIENTS 10
#define MAX_ATTEMPTS 3
#define BLOCK_TIME 60 // Время блокировки в секундах
#define IP_ADDRESS_LENGTH 16 // Длина строки для хранения IPv4 адреса

struct ClientInfo {
    char ip[IP_ADDRESS_LENGTH];
    int failed_attempts;
    std::chrono::time_point<std::chrono::steady_clock> block_time;
};

ClientInfo clients[MAX_CLIENTS];
std::mutex client_mutex; // Мьютекс для защиты данных клиентов

void init_clients() {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        clients[i].failed_attempts = 0;
        clients[i].block_time = std::chrono::steady_clock::now();
        memset(clients[i].ip, 0, IP_ADDRESS_LENGTH);
    }
}

int find_client(const char* ip) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (strcmp(clients[i].ip, ip) == 0) {
            return i;
        }
    }
    return -1;
}

void handle_client(SOCKET client_socket, const char* client_ip) {
    char buffer[256];
    const char* valid_username = "user";
    const char* valid_password = "password";

    int client_index = find_client(client_ip);
    if (client_index == -1) {
        client_index = find_client("");
        strcpy(clients[client_index].ip, client_ip);
    }

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); // Задержка для уменьшения нагрузки на сервер

        // Проверка на блокировку
        std::lock_guard<std::mutex> lock(client_mutex); // Защита данных о клиентах
        if (clients[client_index].failed_attempts >= MAX_ATTEMPTS) {
            auto current_time = std::chrono::steady_clock::now();
            if (std::chrono::duration_cast<std::chrono::seconds>(current_time - clients[client_index].block_time).count() < BLOCK_TIME) {
                // Если клиент заблокирован
                char response[256];
                int remaining_time = BLOCK_TIME - std::chrono::duration_cast<std::chrono::seconds>(current_time - clients[client_index].block_time).count();
                sprintf(response, "Your IP is blocked. Please try again in %d seconds.\n", remaining_time);
                send(client_socket, response, strlen(response), 0);
                continue; // Игнорируем ввод клиента во время блокировки
            }
            else {
                // Сбросить попытки после истечения времени блокировки
                clients[client_index].failed_attempts = 0;
            }
        }

        // Запрос логина и пароля только если клиент не заблокирован
        const char* request = "Enter username and password (format: username password):\n";
        send(client_socket, request, strlen(request), 0);

        int recv_len = recv(client_socket, buffer, sizeof(buffer) - 1, 0);

        if (recv_len <= 0) {
            break; // Ошибка или закрытие соединения
        }

        buffer[recv_len] = '\0'; // Добавляем нуль-терминатор для корректного отображения строки

        // Разделение логина и пароля
        char username[128], password[128];
        sscanf(buffer, "%s %s", username, password);

        // Проверка логина и пароля
        if (strcmp(username, valid_username) == 0 && strcmp(password, valid_password) == 0) {
            const char* response = "Login successful!\n";
            send(client_socket, response, strlen(response), 0);
            break; // Выход из цикла после успешного входа
        }
        else {
            clients[client_index].failed_attempts++;
            if (clients[client_index].failed_attempts >= MAX_ATTEMPTS) {
                clients[client_index].block_time = std::chrono::steady_clock::now(); // Запомнить время блокировки
                const char* response = "Too many failed attempts. Your IP is now blocked for 1 minute.\n";
                send(client_socket, response, strlen(response), 0);
            }
            else {
                char response[256];
                sprintf(response, "Invalid credentials. Attempts left: %d\n", MAX_ATTEMPTS - clients[client_index].failed_attempts);
                send(client_socket, response, strlen(response), 0);
            }
        }
    }

    closesocket(client_socket); // Закрываем сокет клиента после завершения работы с ним
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int port = atoi(argv[1]);

    WSADATA wsaData;
    SOCKET server_socket;

    WSAStartup(MAKEWORD(2, 2), &wsaData);

    server_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY; // Слушаем на всех интерфейсах
    server_addr.sin_port = htons(port);

    bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr));

    listen(server_socket, SOMAXCONN); // Начинаем слушать входящие соединения

    init_clients();

    printf("Server listening on port %d...\n", port);

    while (true) {
        SOCKET client_socket = accept(server_socket, NULL, NULL);

        if (client_socket != INVALID_SOCKET) {
            char client_ip[IP_ADDRESS_LENGTH];
            struct sockaddr_in client_addr;
            int addr_len = sizeof(client_addr);
            getpeername(client_socket, (struct sockaddr*)&client_addr, &addr_len);
            inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, sizeof(client_ip));
            printf("Client connected: %s\n", client_ip);

            std::thread(handle_client, client_socket, client_ip).detach(); // Создаем новый поток для обработки клиента
        }
    }

    closesocket(server_socket); // Закрываем серверный сокет при завершении работы
    WSACleanup();

    return EXIT_SUCCESS;
}
