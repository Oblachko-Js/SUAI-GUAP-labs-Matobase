// cottagecalc.h
#ifndef COTTAGECALC_H
#define COTTAGECALC_H

#include "abstractcalc.h" // Добавляем заголовочный файл для AbstractCalc
#include <estate.h>

class CottageCalc : public AbstractCalc { // Наследуемся от AbstractCalc
public:
    int calculateCost(Estate *estate) override; // Переопределяем метод calculateCost
};

#endif // COTTAGECALC_H
