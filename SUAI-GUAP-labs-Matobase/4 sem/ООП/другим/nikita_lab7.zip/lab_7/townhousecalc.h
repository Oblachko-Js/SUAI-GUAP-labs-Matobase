// townhousecalc.h
#ifndef TOWNHOUSECALC_H
#define TOWNHOUSECALC_H

#include "abstractcalc.h" // Добавляем заголовочный файл для AbstractCalc
#include <estate.h>

class TownhouseCalc : public AbstractCalc { // Наследуемся от AbstractCalc
public:
    int calculateCost(Estate *estate) override; // Переопределяем метод calculateCost
};

#endif // TOWNHOUSECALC_H
