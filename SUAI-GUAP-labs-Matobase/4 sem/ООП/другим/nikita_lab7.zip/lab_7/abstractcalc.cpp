#include "abstractcalc.h"

AbstractCalc::AbstractCalc() {
    // реализация конструктора
}

AbstractCalc::~AbstractCalc() {
    // реализация деструктора
}
