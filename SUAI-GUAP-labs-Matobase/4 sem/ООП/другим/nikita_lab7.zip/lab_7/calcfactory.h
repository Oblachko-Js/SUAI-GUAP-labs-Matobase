// calcfactory.h
#ifndef CALCFACTORY_H
#define CALCFACTORY_H

#include "abstractcalc.h"
#include "estate.h"

class CalcFactory {
public:
    static AbstractCalc* createCalculator(EstateType type);
};

#endif // CALCFACTORY_H
