// luxuriousapartmentcalc.h
#ifndef LUXURIOUSAPARTMENTCALC_H
#define LUXURIOUSAPARTMENTCALC_H

#include "abstractcalc.h" // Добавляем заголовочный файл для AbstractCalc
#include <estate.h>

class LuxuriousApartmentCalc : public AbstractCalc { // Наследуемся от AbstractCalc
public:
    int calculateCost(Estate *estate) override; // Переопределяем метод calculateCost
};

#endif // LUXURIOUSAPARTMENTCALC_H
