// apartmentcalc.h
#ifndef APARTMENTCALC_H
#define APARTMENTCALC_H

#include "abstractcalc.h" // Добавляем заголовочный файл для AbstractCalc
#include <estate.h>

class ApartmentCalc : public AbstractCalc { // Наследуемся от AbstractCalc
public:
    int calculateCost(Estate *estate) override; // Переопределяем метод calculateCost
};

#endif // APARTMENTCALC_H
