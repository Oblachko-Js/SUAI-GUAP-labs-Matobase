// calcfactory.cpp
#include "calcfactory.h"
#include "apartmentcalc.h"
#include "luxuriousapartmentcalc.h"
#include "townhousecalc.h"
#include "cottagecalc.h"

AbstractCalc* CalcFactory::createCalculator(EstateType type) {
    switch (type) {
        case ECONOM:
            return new ApartmentCalc();
        case LUXURIOUS:
            return new LuxuriousApartmentCalc();
        case TOWN_HOUSE:
            return new TownhouseCalc();
        case COTTAGE:
            return new CottageCalc();
        default:
            return nullptr;
    }
}
