// calculationfacade.cpp
#include "calculationfacade.h"
#include "calcfactory.h"

CalculationFacade::CalculationFacade(QObject *parent) : QObject(parent) {
}

int CalculationFacade::getCost(Estate *value) {
    AbstractCalc* calc = CalcFactory::createCalculator(value->getType());
    if (calc) {
        int cost = calc->calculateCost(value);
        delete calc;
        return cost;
    } else {
        return -1; // Возвращаем значение по умолчанию в случае ошибки
    }
}
