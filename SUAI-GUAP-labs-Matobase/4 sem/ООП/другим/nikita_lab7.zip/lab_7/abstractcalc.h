#ifndef ABSTRACTCALC_H
#define ABSTRACTCALC_H
#include "estate.h"

class AbstractCalc {
public:
    AbstractCalc(); // объявление конструктора
    virtual ~AbstractCalc(); // объявление виртуального деструктора

    virtual int calculateCost(Estate *value) = 0; // чисто виртуальная функция
};

#endif // ABSTRACTCALC_H
