#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidget>
#include <QString>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void onAddElementButtonClicked();
    void onSumElementButtonClicked();
    void onSumEvenNumbersButtonClicked();
    void moveItemToOriginal(QListWidgetItem *item);
    void moveItemsToOriginal();
    void onViewElementByIndexButtonClicked();
    void onDeleteElementByIndexButtonClicked();
    void onDeleteElementByValueButtonClicked();
    void onClearCollectionButtonClicked();
    void onAddCollectionButtonClicked();
    void onSaveCollectionButtonClicked();
    void onPushButtonNeotricZnachClicked();
    void on_pushButton_sum_clicked();

private:
    Ui::MainWindow *ui;

    class CollectionManager
    {
    public:
        CollectionManager(QListWidget *listWidgetOriginal, QListWidget *listWidgetConverted, MainWindow *mainWindow);
        void addElement(const QString &elementText);
        int calculateSum();
        int calculateSumEvenNumbers();

    private:
        QListWidget *listWidgetOriginal;
        QListWidget *listWidgetConverted;
        MainWindow *mainWindow;
    };

    CollectionManager *collectionManager;
};

#endif // MAINWINDOW_H
