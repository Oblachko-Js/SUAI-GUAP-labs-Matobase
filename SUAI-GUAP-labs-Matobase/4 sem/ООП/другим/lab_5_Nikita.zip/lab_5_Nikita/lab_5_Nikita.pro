#-------------------------------------------------
#
# Project created by QtCreator 2024-03-14T10:31:45
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = lab_5_Nikita
TEMPLATE = app


SOURCES += main.cpp\
        mainwindow.cpp

HEADERS  += mainwindow.h

FORMS    += mainwindow.ui

CONFIG += C++11

RESOURCES += \
    src.qrc
