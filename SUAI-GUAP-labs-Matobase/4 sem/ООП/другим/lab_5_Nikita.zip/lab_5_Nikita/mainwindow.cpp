#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QListWidgetItem>
#include <QFile>
#include <QTextStream>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Создаем экземпляр CollectionManager и передаем ему указатели на QListWidget и на сам MainWindow
    collectionManager = new CollectionManager(ui->listWidget_original, ui->listWidget_converted, this);

    // Соединяем сигнал нажатия кнопки с соответствующими слотами
    connect(ui->pushButton_add_el, &QPushButton::clicked, this, &MainWindow::onAddElementButtonClicked);
    connect(ui->pushButton_sum_el, &QPushButton::clicked, this, &MainWindow::onSumElementButtonClicked);
    connect(ui->pushButton_sum_even_numbers, &QPushButton::clicked, this, &MainWindow::onSumEvenNumbersButtonClicked);
    connect(ui->pushButton_view_el_by_index, &QPushButton::clicked, this, &MainWindow::onViewElementByIndexButtonClicked);
    connect(ui->pushButton_delet_el_by_index, &QPushButton::clicked, this, &MainWindow::onDeleteElementByIndexButtonClicked);
    connect(ui->pushButton_delet_el_by_value, &QPushButton::clicked, this, &MainWindow::onDeleteElementByValueButtonClicked);
    connect(ui->pushButton_clear_collection, &QPushButton::clicked, this, &MainWindow::onClearCollectionButtonClicked);
    connect(ui->pushButton_add_collection, &QPushButton::clicked, this, &MainWindow::onAddCollectionButtonClicked);
    connect(ui->pushButton_save_collection_in_file, &QPushButton::clicked, this, &MainWindow::onSaveCollectionButtonClicked);
    connect(ui->pushButton_neotric_znach, &QPushButton::clicked, this, &MainWindow::onPushButtonNeotricZnachClicked);
    connect(ui->pushButton_sum, &QPushButton::clicked, this, &MainWindow::on_pushButton_sum_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete collectionManager;
}

void MainWindow::onAddElementButtonClicked()
{
    ui->label_value_show_el->setText("...");
    ui->label_befor_sum->setText("...");
    ui->labelmetod_sum->setText("...");
    // Получаем текст из lineEdit_value_el
    QString elementText = ui->lineEdit_value_el->text();

    // Проверяем, что текст не пустой
    if (!elementText.isEmpty())
    {
        // Используем метод addElement из CollectionManager
        collectionManager->addElement(elementText);

        // Очищаем lineEdit после добавления элемента, если нужно
        ui->lineEdit_value_el->clear();
    }
}

void MainWindow::onSumElementButtonClicked()
{
    // Вызываем метод calculateSum из CollectionManager
    int sum = collectionManager->calculateSum();

    // Выводим сумму в label_befor_sum
    ui->label_befor_sum->setText("Сумма: " + QString::number(sum));
}

void MainWindow::onSumEvenNumbersButtonClicked()
{
    // Вызываем метод calculateSumEvenNumbers из CollectionManager
    int sumEven = collectionManager->calculateSumEvenNumbers();

    // Выводим сумму четных чисел в label_befor_sum
    ui->label_befor_sum->setText("Сумма четных: " + QString::number(sumEven));
}

void MainWindow::moveItemToOriginal(QListWidgetItem *item)
{
    ui->label_value_show_el->setText("...");
    ui->label_befor_sum->setText("...");
    ui->labelmetod_sum->setText("...");
    if (item)
    {
        // Удаляем элемент из listWidget_converted
        ui->listWidget_converted->takeItem(ui->listWidget_converted->row(item));

        // Добавляем элемент в listWidget_original
        ui->listWidget_original->addItem(item);
    }
}

void MainWindow::moveItemsToOriginal()
{
    ui->label_value_show_el->setText("...");
    ui->label_befor_sum->setText("...");
    ui->labelmetod_sum->setText("...");
    // Очищаем listWidget_original перед копированием
    ui->listWidget_original->clear();

    // Копируем все элементы из listWidget_converted в listWidget_original
    for (int i = 0; i < ui->listWidget_converted->count(); ++i)
    {
        QListWidgetItem *item = ui->listWidget_converted->item(i);
        if (item)
        {
            // Создаем копию элемента
            QListWidgetItem *copyItem = new QListWidgetItem(*item);

            // Добавляем копию элемента в listWidget_original
            ui->listWidget_original->addItem(copyItem);
        }
    }
}

// Определение методов CollectionManager

MainWindow::CollectionManager::CollectionManager(QListWidget *listWidgetOriginal, QListWidget *listWidgetConverted, MainWindow *mainWindow)
    : listWidgetOriginal(listWidgetOriginal), listWidgetConverted(listWidgetConverted), mainWindow(mainWindow)
{

}

void MainWindow::CollectionManager::addElement(const QString &elementText)
{
    if (listWidgetConverted)
    {
        // Перемещаем все элементы из QListWidget_converted в QListWidget_original
        mainWindow->moveItemsToOriginal();
        // Создаем новый элемент для QListWidget
        QListWidgetItem *newItem = new QListWidgetItem(elementText);

        // Добавляем элемент в QListWidget_converted
        listWidgetConverted->addItem(newItem);
    }
}

int MainWindow::CollectionManager::calculateSum()
{
    int sum = 0;
    for (int i = 0; i < listWidgetConverted->count(); ++i)
    {
        QListWidgetItem *item = listWidgetConverted->item(i);
        if (item)
        {
            // Парсим текст элемента в число и добавляем к сумме
            bool ok;
            int value = item->text().toInt(&ok);
            if (ok)
            {
                sum += value;
            }
        }
    }
    return sum;
}

int MainWindow::CollectionManager::calculateSumEvenNumbers()
{
    int sumEven = 0;
    for (int i = 0; i < listWidgetConverted->count(); ++i)
    {
        QListWidgetItem *item = listWidgetConverted->item(i);
        if (item)
        {
            // Парсим текст элемента в число
            bool ok;
            int value = item->text().toInt(&ok);
            if (ok)
            {
                // Проверяем, является ли число четным, и добавляем к сумме
                if (value % 2 == 0)
                {
                    sumEven += value;
                }
            }
        }
    }
    return sumEven;
}

void MainWindow::onViewElementByIndexButtonClicked()
{
    // Получаем индекс из lineEdit_index_el
    int index = ui->lineEdit_index_el->text().toInt();

    // Проверяем, что индекс в допустимом диапазоне
    if (index >= 0 && index < ui->listWidget_converted->count())
    {
        // Получаем элемент по индексу
        QListWidgetItem *item = ui->listWidget_converted->item(index);

        // Проверяем, что элемент существует
        if (item)
        {
            // Отображаем значение элемента в label_value_show_el
            ui->label_value_show_el->setText(item->text());
        }
        else
        {
            // Если элемент не существует, очищаем label_value_show_el
            ui->label_value_show_el->clear();
        }
    }
    else
    {
        // Если индекс не в допустимом диапазоне, очищаем label_value_show_el
        ui->label_value_show_el->clear();
    }
}

void MainWindow::onDeleteElementByIndexButtonClicked()
{
    // Получаем индекс из lineEdit_index_el
    int index = ui->lineEdit_index_el->text().toInt();

    // Проверяем, что индекс в допустимом диапазоне
    if (index >= 0 && index < ui->listWidget_converted->count())
    {
        // Копируем элементы из listWidget_converted в listWidget_original
        moveItemsToOriginal();

        // Удаляем элемент из listWidget_converted
        delete ui->listWidget_converted->takeItem(index);
    }
}

void MainWindow::onDeleteElementByValueButtonClicked()
{
    // Получаем текст из lineEdit_value_el
    QString elementText = ui->lineEdit_value_el->text();

    // Поиск элемента с заданным текстом в listWidget_converted
    QList<QListWidgetItem *> items = ui->listWidget_converted->findItems(elementText, Qt::MatchExactly);

    // Проверяем, что найден хотя бы один элемент
    if (!items.isEmpty())
    {
        // Копируем элементы из listWidget_converted в listWidget_original
        moveItemsToOriginal();

        // Удаляем найденные элементы из listWidget_converted
        for (QListWidgetItem *item : items)
        {
            delete ui->listWidget_converted->takeItem(ui->listWidget_converted->row(item));
        }
    }
}

void MainWindow::onClearCollectionButtonClicked()
{
    // Копируем все элементы из listWidget_converted в listWidget_original
    moveItemsToOriginal();

    // Очищаем listWidget_converted
    ui->listWidget_converted->clear();
}

void MainWindow::onAddCollectionButtonClicked()
{
    // Получаем выбор пользователя из выпадающего списка
    QString selectedFile = ui->comboBox_file->currentText();

    // Проверяем, что файл выбран и это main.txt или main.csv
    if (!selectedFile.isEmpty() && (selectedFile == "main.txt" || selectedFile == "main.csv" || selectedFile == "main.json" || selectedFile == "main.xml"))
    {
        // Открываем файл для чтения
        QFile file(selectedFile);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            // Читаем данные из файла
            QTextStream in(&file);
            while (!in.atEnd())
            {
                QString line = in.readLine();
                // Используем метод addElement из CollectionManager
                collectionManager->addElement(line);
                ui->listWidget_original->clear();
            }

            // Закрываем файл после чтения
            file.close();
        }
        else
        {
            // В случае ошибки открытия файла вы можете обработать ошибку
            qDebug() << "Error opening file: " << file.errorString();
        }
    }
    else
    {
        // Если файл не выбран или это не main.txt или main.csv, вы можете предпринять соответствующие действия
        qDebug() << "Invalid file selected";
    }
}

void MainWindow::onSaveCollectionButtonClicked()
{
    // Получаем выбор пользователя из выпадающего списка
    QString selectedFile = ui->comboBox_file->currentText();

    // Проверяем, что файл выбран и это main.txt или main.csv или другие поддерживаемые форматы
    if (!selectedFile.isEmpty() && (selectedFile == "main.txt" || selectedFile == "main.csv" || selectedFile == "main.json" || selectedFile == "main.xml"))
    {
        // Открываем файл для записи
        QFile file(selectedFile);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            // Создаем поток для записи в файл
            QTextStream out(&file);

            // Получаем количество элементов в listWidget_converted
            int itemCount = ui->listWidget_converted->count();

            // Записываем каждый элемент в файл
            for (int i = 0; i < itemCount; ++i)
            {
                QListWidgetItem *item = ui->listWidget_converted->item(i);
                if (item)
                {
                    // Записываем текст элемента в файл
                    out << item->text() << "\n";
                }
            }

            // Закрываем файл после записи
            file.close();
        }
        else
        {
            // В случае ошибки открытия файла для записи
            qDebug() << "Error opening file for writing: " << file.errorString();
        }
    }
    else
    {
        // Если файл не выбран
        qDebug() << "Invalid file selected";
    }
}

void MainWindow::onPushButtonNeotricZnachClicked()
{
    // Создаем новую последовательность для неотрицательных элементов
    QList<QListWidgetItem *> nonNegativeItems;
    for (int i = 0; i < ui->listWidget_converted->count(); ++i)
    {
        QListWidgetItem *item = ui->listWidget_converted->item(i);
        if (item)
        {
            // Парсим текст элемента в число
            bool ok;
            int value = item->text().toInt(&ok);
            if (ok && value >= 0)
            {
                // Добавляем элемент в новую последовательность, если он неотрицательный
                nonNegativeItems.append(item);
            }
        }
    }

    // Очищаем listWidget_original перед копированием
    ui->listWidget_original->clear();

    // Копируем все элементы из nonNegativeItems в listWidget_original
    for (QListWidgetItem *item : nonNegativeItems)
    {
        // Создаем копию элемента
        QListWidgetItem *copyItem = new QListWidgetItem(*item);

        // Добавляем копию элемента в listWidget_original
        ui->listWidget_original->addItem(copyItem);
    }
}

void MainWindow::on_pushButton_sum_clicked()
{
    // Находим индексы первого и последнего нулевых элементов
    int firstZeroIndex = -1;
    int lastZeroIndex = -1;

    // Итерируемся по элементам в listWidget_converted
    for (int i = 0; i < ui->listWidget_converted->count(); ++i)
    {
        QListWidgetItem *item = ui->listWidget_converted->item(i);

        if (item)
        {
            if (item->text().toInt() == 0)
            {
                if (firstZeroIndex == -1)
                    firstZeroIndex = i;
                lastZeroIndex = i;
            }
        }
    }

    // Проверяем, что нашли хотя бы один нулевой элемент
    if (firstZeroIndex != -1 && lastZeroIndex != -1)
    {
        // Вычисляем сумму элементов между первым и последним нулевыми элементами
        int sum = 0;
        for (int i = firstZeroIndex + 1; i < lastZeroIndex; ++i)
        {
            QListWidgetItem *item = ui->listWidget_converted->item(i);
            if (item)
            {
                sum += item->text().toInt();
            }
        }

        // Выводим результат
        ui->labelmetod_sum->setText("Сумма: " + QString::number(sum));
    }
    else
    {
        // Если ни одного нулевого элемента не найдено
        ui->labelmetod_sum->setText("Не найдено последовательности с нулями");
    }
}
