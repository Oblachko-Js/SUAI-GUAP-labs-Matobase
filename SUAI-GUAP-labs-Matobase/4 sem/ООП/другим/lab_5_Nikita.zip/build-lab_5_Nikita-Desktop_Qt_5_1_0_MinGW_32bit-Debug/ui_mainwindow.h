/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label_original;
    QLabel *label_converted;
    QPushButton *pushButton_view_el_by_index;
    QPushButton *pushButton_delet_el_by_index;
    QLabel *label_metod_container;
    QLineEdit *lineEdit_index_el;
    QLabel *label_index;
    QPushButton *pushButton_delet_el_by_value;
    QLabel *label_value;
    QLineEdit *lineEdit_value_el;
    QLabel *label_sum;
    QLabel *label_eazy_programming;
    QLabel *labelmetod_container;
    QPushButton *pushButton_add_el;
    QPushButton *pushButton_sum_el;
    QPushButton *pushButton_sum_even_numbers;
    QPushButton *pushButton_add_collection;
    QPushButton *pushButton_save_collection_in_file;
    QPushButton *pushButton_clear_collection;
    QLabel *label_name_file;
    QComboBox *comboBox_file;
    QLabel *label_befor_sum;
    QListWidget *listWidget_original;
    QListWidget *listWidget_converted;
    QLabel *label_value_show_el;
    QLabel *labelmetod_zadanya;
    QPushButton *pushButton_neotric_znach;
    QLabel *labelmetod_zadanya_2;
    QPushButton *pushButton_sum;
    QLabel *labelmetod_sum;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1147, 827);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label_original = new QLabel(centralWidget);
        label_original->setObjectName(QStringLiteral("label_original"));
        label_original->setGeometry(QRect(580, 30, 271, 21));
        QFont font;
        font.setPointSize(12);
        label_original->setFont(font);
        label_converted = new QLabel(centralWidget);
        label_converted->setObjectName(QStringLiteral("label_converted"));
        label_converted->setGeometry(QRect(880, 30, 191, 21));
        label_converted->setFont(font);
        pushButton_view_el_by_index = new QPushButton(centralWidget);
        pushButton_view_el_by_index->setObjectName(QStringLiteral("pushButton_view_el_by_index"));
        pushButton_view_el_by_index->setGeometry(QRect(0, 60, 341, 28));
        pushButton_view_el_by_index->setFont(font);
        pushButton_delet_el_by_index = new QPushButton(centralWidget);
        pushButton_delet_el_by_index->setObjectName(QStringLiteral("pushButton_delet_el_by_index"));
        pushButton_delet_el_by_index->setGeometry(QRect(0, 100, 341, 28));
        pushButton_delet_el_by_index->setFont(font);
        label_metod_container = new QLabel(centralWidget);
        label_metod_container->setObjectName(QStringLiteral("label_metod_container"));
        label_metod_container->setGeometry(QRect(0, 30, 341, 21));
        label_metod_container->setFont(font);
        label_metod_container->setAlignment(Qt::AlignCenter);
        lineEdit_index_el = new QLineEdit(centralWidget);
        lineEdit_index_el->setObjectName(QStringLiteral("lineEdit_index_el"));
        lineEdit_index_el->setGeometry(QRect(370, 60, 191, 28));
        lineEdit_index_el->setFont(font);
        label_index = new QLabel(centralWidget);
        label_index->setObjectName(QStringLiteral("label_index"));
        label_index->setGeometry(QRect(370, 30, 191, 21));
        label_index->setFont(font);
        label_index->setAlignment(Qt::AlignCenter);
        pushButton_delet_el_by_value = new QPushButton(centralWidget);
        pushButton_delet_el_by_value->setObjectName(QStringLiteral("pushButton_delet_el_by_value"));
        pushButton_delet_el_by_value->setGeometry(QRect(0, 140, 341, 28));
        pushButton_delet_el_by_value->setFont(font);
        label_value = new QLabel(centralWidget);
        label_value->setObjectName(QStringLiteral("label_value"));
        label_value->setGeometry(QRect(370, 140, 191, 21));
        label_value->setFont(font);
        label_value->setAlignment(Qt::AlignCenter);
        lineEdit_value_el = new QLineEdit(centralWidget);
        lineEdit_value_el->setObjectName(QStringLiteral("lineEdit_value_el"));
        lineEdit_value_el->setGeometry(QRect(370, 170, 191, 28));
        lineEdit_value_el->setFont(font);
        label_sum = new QLabel(centralWidget);
        label_sum->setObjectName(QStringLiteral("label_sum"));
        label_sum->setGeometry(QRect(370, 250, 191, 21));
        label_sum->setFont(font);
        label_sum->setAlignment(Qt::AlignCenter);
        label_eazy_programming = new QLabel(centralWidget);
        label_eazy_programming->setObjectName(QStringLiteral("label_eazy_programming"));
        label_eazy_programming->setGeometry(QRect(0, 220, 341, 21));
        label_eazy_programming->setFont(font);
        label_eazy_programming->setAlignment(Qt::AlignCenter);
        labelmetod_container = new QLabel(centralWidget);
        labelmetod_container->setObjectName(QStringLiteral("labelmetod_container"));
        labelmetod_container->setGeometry(QRect(0, 410, 341, 21));
        labelmetod_container->setFont(font);
        labelmetod_container->setAlignment(Qt::AlignCenter);
        pushButton_add_el = new QPushButton(centralWidget);
        pushButton_add_el->setObjectName(QStringLiteral("pushButton_add_el"));
        pushButton_add_el->setGeometry(QRect(0, 250, 341, 28));
        pushButton_add_el->setFont(font);
        pushButton_sum_el = new QPushButton(centralWidget);
        pushButton_sum_el->setObjectName(QStringLiteral("pushButton_sum_el"));
        pushButton_sum_el->setGeometry(QRect(0, 290, 341, 28));
        pushButton_sum_el->setFont(font);
        pushButton_sum_even_numbers = new QPushButton(centralWidget);
        pushButton_sum_even_numbers->setObjectName(QStringLiteral("pushButton_sum_even_numbers"));
        pushButton_sum_even_numbers->setGeometry(QRect(0, 330, 341, 28));
        pushButton_sum_even_numbers->setFont(font);
        pushButton_add_collection = new QPushButton(centralWidget);
        pushButton_add_collection->setObjectName(QStringLiteral("pushButton_add_collection"));
        pushButton_add_collection->setGeometry(QRect(0, 440, 341, 28));
        pushButton_add_collection->setFont(font);
        pushButton_save_collection_in_file = new QPushButton(centralWidget);
        pushButton_save_collection_in_file->setObjectName(QStringLiteral("pushButton_save_collection_in_file"));
        pushButton_save_collection_in_file->setGeometry(QRect(0, 480, 341, 28));
        pushButton_save_collection_in_file->setFont(font);
        pushButton_clear_collection = new QPushButton(centralWidget);
        pushButton_clear_collection->setObjectName(QStringLiteral("pushButton_clear_collection"));
        pushButton_clear_collection->setGeometry(QRect(0, 520, 341, 28));
        pushButton_clear_collection->setFont(font);
        label_name_file = new QLabel(centralWidget);
        label_name_file->setObjectName(QStringLiteral("label_name_file"));
        label_name_file->setGeometry(QRect(370, 410, 191, 21));
        label_name_file->setFont(font);
        label_name_file->setAlignment(Qt::AlignCenter);
        comboBox_file = new QComboBox(centralWidget);
        comboBox_file->setObjectName(QStringLiteral("comboBox_file"));
        comboBox_file->setGeometry(QRect(370, 440, 191, 28));
        label_befor_sum = new QLabel(centralWidget);
        label_befor_sum->setObjectName(QStringLiteral("label_befor_sum"));
        label_befor_sum->setGeometry(QRect(370, 290, 191, 20));
        label_befor_sum->setFont(font);
        label_befor_sum->setAlignment(Qt::AlignCenter);
        listWidget_original = new QListWidget(centralWidget);
        listWidget_original->setObjectName(QStringLiteral("listWidget_original"));
        listWidget_original->setGeometry(QRect(680, 60, 71, 491));
        listWidget_converted = new QListWidget(centralWidget);
        listWidget_converted->setObjectName(QStringLiteral("listWidget_converted"));
        listWidget_converted->setGeometry(QRect(940, 60, 71, 491));
        label_value_show_el = new QLabel(centralWidget);
        label_value_show_el->setObjectName(QStringLiteral("label_value_show_el"));
        label_value_show_el->setGeometry(QRect(370, 90, 191, 21));
        label_value_show_el->setFont(font);
        label_value_show_el->setAlignment(Qt::AlignCenter);
        labelmetod_zadanya = new QLabel(centralWidget);
        labelmetod_zadanya->setObjectName(QStringLiteral("labelmetod_zadanya"));
        labelmetod_zadanya->setGeometry(QRect(0, 600, 401, 21));
        labelmetod_zadanya->setFont(font);
        labelmetod_zadanya->setAlignment(Qt::AlignCenter);
        pushButton_neotric_znach = new QPushButton(centralWidget);
        pushButton_neotric_znach->setObjectName(QStringLiteral("pushButton_neotric_znach"));
        pushButton_neotric_znach->setGeometry(QRect(0, 630, 401, 28));
        pushButton_neotric_znach->setFont(font);
        labelmetod_zadanya_2 = new QLabel(centralWidget);
        labelmetod_zadanya_2->setObjectName(QStringLiteral("labelmetod_zadanya_2"));
        labelmetod_zadanya_2->setGeometry(QRect(430, 600, 441, 21));
        labelmetod_zadanya_2->setFont(font);
        labelmetod_zadanya_2->setAlignment(Qt::AlignCenter);
        pushButton_sum = new QPushButton(centralWidget);
        pushButton_sum->setObjectName(QStringLiteral("pushButton_sum"));
        pushButton_sum->setGeometry(QRect(430, 630, 441, 28));
        pushButton_sum->setFont(font);
        labelmetod_sum = new QLabel(centralWidget);
        labelmetod_sum->setObjectName(QStringLiteral("labelmetod_sum"));
        labelmetod_sum->setGeometry(QRect(430, 680, 441, 21));
        labelmetod_sum->setFont(font);
        labelmetod_sum->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1147, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Borsh_N_4236", 0));
        label_original->setText(QApplication::translate("MainWindow", "\320\232\320\276\320\273\320\273\320\265\320\272\321\206\320\270\321\217 \320\262\321\201\320\277\320\276\320\274\320\276\320\263\320\260\321\202\320\265\320\273\321\214\320\275\320\260\321\217", 0));
        label_converted->setText(QApplication::translate("MainWindow", "\320\232\320\276\320\273\320\273\320\265\320\272\321\206\320\270\321\217 \321\200\320\260\320\261\320\276\321\207\320\260\321\217", 0));
        pushButton_view_el_by_index->setText(QApplication::translate("MainWindow", "\320\237\320\276\320\272\320\260\320\267\320\260\321\202\321\214 \321\215\320\273. \320\277\320\276 \320\270\320\275\320\264\320\265\320\272\321\201\321\203", 0));
        pushButton_delet_el_by_index->setText(QApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214 \321\215\320\273. \320\277\320\276 \320\270\320\275\320\264\320\265\320\272\321\201\321\203", 0));
        label_metod_container->setText(QApplication::translate("MainWindow", "\320\234\320\265\321\202\320\276\320\264\321\213 \320\272\320\276\320\275\321\202\320\265\320\271\320\275\320\265\321\200\320\260", 0));
        label_index->setText(QApplication::translate("MainWindow", "\320\230\320\275\320\264\320\265\320\272\321\201 \321\215\320\273\320\273\320\265\320\274\320\265\320\275\321\202\320\260", 0));
        pushButton_delet_el_by_value->setText(QApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214 \321\215\320\273. \320\277\320\276 \320\267\320\275\320\260\321\207\320\265\320\275\320\270\321\216", 0));
        label_value->setText(QApplication::translate("MainWindow", "\320\227\320\275\320\260\321\207\320\265\320\275\320\270\320\265 \321\215\320\273\320\273\320\265\320\274\320\265\320\275\321\202\320\260", 0));
        label_sum->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260", 0));
        label_eazy_programming->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\276\321\201\321\202\320\276\320\265 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\270\321\200\320\276\320\262\320\260\320\275\320\270\320\265", 0));
        labelmetod_container->setText(QApplication::translate("MainWindow", "\320\234\320\265\321\202\320\276\320\264\321\213 \320\272\320\276\320\275\321\202\320\265\320\271\320\275\320\265\321\200\320\260", 0));
        pushButton_add_el->setText(QApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\215\320\273\320\265\320\274\320\265\320\275\321\202", 0));
        pushButton_sum_el->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260 \321\215\320\273\320\265\320\274\320\265\320\275\321\202\320\276\320\262", 0));
        pushButton_sum_even_numbers->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260 \321\207\320\265\321\202\320\275\321\213\321\205 \321\215\320\273\320\265\320\274\320\265\320\275\321\202\320\276\320\262", 0));
        pushButton_add_collection->setText(QApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\272\320\276\320\273\320\265\320\272\321\206\320\270\321\216 \320\270\320\267 \321\204\320\260\320\271\320\273\320\260", 0));
        pushButton_save_collection_in_file->setText(QApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214 \320\272\320\276\320\273\320\265\320\272\321\206\320\270\321\216 \320\262 \321\204\320\260\320\271\320\273\320\265", 0));
        pushButton_clear_collection->setText(QApplication::translate("MainWindow", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214 \320\272\320\276\320\273\320\265\320\272\321\206\320\270\321\216", 0));
        label_name_file->setText(QApplication::translate("MainWindow", "\320\230\320\274\321\217 \321\204\320\260\320\271\320\273\320\260", 0));
        comboBox_file->clear();
        comboBox_file->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "...", 0)
         << QApplication::translate("MainWindow", "main.txt", 0)
         << QApplication::translate("MainWindow", "main.csv", 0)
         << QApplication::translate("MainWindow", "main.json", 0)
         << QApplication::translate("MainWindow", "main.xml", 0)
        );
        label_befor_sum->setText(QApplication::translate("MainWindow", "...", 0));
        label_value_show_el->setText(QApplication::translate("MainWindow", "...", 0));
        labelmetod_zadanya->setText(QApplication::translate("MainWindow", "\320\233\320\270\321\207\320\275\321\213\320\265 \320\267\320\260\320\264\320\260\320\275\320\270\321\217 1", 0));
        pushButton_neotric_znach->setText(QApplication::translate("MainWindow", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \320\272\320\276\320\273\320\273\320\265\320\272\321\206\320\270\321\216 \320\270\320\267 \320\275\320\265\320\276\321\202\321\200\320\270\321\206. \320\267\320\275\320\260\321\207.", 0));
        labelmetod_zadanya_2->setText(QApplication::translate("MainWindow", "\320\233\320\270\321\207\320\275\321\213\320\265 \320\267\320\260\320\264\320\260\320\275\320\270\321\217 2", 0));
        pushButton_sum->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260 \321\215\320\273. \320\274\320\265\320\266\320\264\321\203 \320\277\320\265\321\200\320\262\321\213\320\274 \320\270 \320\277\320\276\321\201\320\273\320\265\320\264\320\275\320\270\320\274 0-\321\215\320\273", 0));
        labelmetod_sum->setText(QApplication::translate("MainWindow", "...", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
