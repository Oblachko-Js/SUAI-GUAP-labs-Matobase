/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.1.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../lab_5_Nikita/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.1.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[17];
    char stringdata[410];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 25),
QT_MOC_LITERAL(2, 37, 0),
QT_MOC_LITERAL(3, 38, 25),
QT_MOC_LITERAL(4, 64, 29),
QT_MOC_LITERAL(5, 94, 18),
QT_MOC_LITERAL(6, 113, 16),
QT_MOC_LITERAL(7, 130, 4),
QT_MOC_LITERAL(8, 135, 19),
QT_MOC_LITERAL(9, 155, 33),
QT_MOC_LITERAL(10, 189, 35),
QT_MOC_LITERAL(11, 225, 35),
QT_MOC_LITERAL(12, 261, 30),
QT_MOC_LITERAL(13, 292, 28),
QT_MOC_LITERAL(14, 321, 29),
QT_MOC_LITERAL(15, 351, 31),
QT_MOC_LITERAL(16, 383, 25)
    },
    "MainWindow\0onAddElementButtonClicked\0"
    "\0onSumElementButtonClicked\0"
    "onSumEvenNumbersButtonClicked\0"
    "moveItemToOriginal\0QListWidgetItem*\0"
    "item\0moveItemsToOriginal\0"
    "onViewElementByIndexButtonClicked\0"
    "onDeleteElementByIndexButtonClicked\0"
    "onDeleteElementByValueButtonClicked\0"
    "onClearCollectionButtonClicked\0"
    "onAddCollectionButtonClicked\0"
    "onSaveCollectionButtonClicked\0"
    "onPushButtonNeotricZnachClicked\0"
    "on_pushButton_sum_clicked\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   79,    2, 0x08,
       3,    0,   80,    2, 0x08,
       4,    0,   81,    2, 0x08,
       5,    1,   82,    2, 0x08,
       8,    0,   85,    2, 0x08,
       9,    0,   86,    2, 0x08,
      10,    0,   87,    2, 0x08,
      11,    0,   88,    2, 0x08,
      12,    0,   89,    2, 0x08,
      13,    0,   90,    2, 0x08,
      14,    0,   91,    2, 0x08,
      15,    0,   92,    2, 0x08,
      16,    0,   93,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->onAddElementButtonClicked(); break;
        case 1: _t->onSumElementButtonClicked(); break;
        case 2: _t->onSumEvenNumbersButtonClicked(); break;
        case 3: _t->moveItemToOriginal((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 4: _t->moveItemsToOriginal(); break;
        case 5: _t->onViewElementByIndexButtonClicked(); break;
        case 6: _t->onDeleteElementByIndexButtonClicked(); break;
        case 7: _t->onDeleteElementByValueButtonClicked(); break;
        case 8: _t->onClearCollectionButtonClicked(); break;
        case 9: _t->onAddCollectionButtonClicked(); break;
        case 10: _t->onSaveCollectionButtonClicked(); break;
        case 11: _t->onPushButtonNeotricZnachClicked(); break;
        case 12: _t->on_pushButton_sum_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
