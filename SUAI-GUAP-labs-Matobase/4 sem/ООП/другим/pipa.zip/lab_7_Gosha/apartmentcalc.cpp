#include "apartmentcalc.h"

int ApartmentCalc::calculateCost(Estate *estate) {

    double area = estate->getArea();
    double period = estate->getMonths();
    double pricePerSquareMeter = 200.0;
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
