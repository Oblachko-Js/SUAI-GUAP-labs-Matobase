#include "cottagecalc.h"

int CottageCalc::calculateCost(Estate *estate) {
    double area = estate->getArea();
    double pricePerSquareMeter = 70;
    double period = estate->getMonths();
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
