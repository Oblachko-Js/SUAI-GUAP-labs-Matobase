#include "luxuriousapartmentcalc.h"

int LuxuriousApartmentCalc::calculateCost(Estate *estate) {
    double area = estate->getArea();
    double pricePerSquareMeter = 1000.0;
    double period = estate->getMonths();
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
