#include "townhousecalc.h"

int TownhouseCalc::calculateCost(Estate *estate) {
    double area = estate->getArea();
    double pricePerSquareMeter = 390;
    double period = estate->getMonths();
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
