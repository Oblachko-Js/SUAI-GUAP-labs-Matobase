#ifndef COTTAGECALC_H
#define COTTAGECALC_H

#include "abstractcalc.h"
#include <estate.h>

class CottageCalc : public AbstractCalc {
public:
    int calculateCost(Estate *estate) override;
};

#endif
