#include "abstractcalc.h"

AbstractCalc::AbstractCalc() {
    // конструктор
}

AbstractCalc::~AbstractCalc() {
    // деструктор
}
