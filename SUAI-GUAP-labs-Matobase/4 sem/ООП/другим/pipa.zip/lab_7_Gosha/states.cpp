#include "states.h"
#include <QDebug>

States::States(QObject *parent) : QObject(parent) {
    actualData = nullptr;
}

States::~States() {
    if (actualData) {
        delete actualData;
        actualData = nullptr;
    }
    qDeleteAll(stack);
    stack.clear();
}

void States::undo() {
    qDebug() << "Undo function called";
    if (!stack.isEmpty()) {
        Estate *previousState = stack.pop();
        emit stateChanged(*previousState);
        emit fillFormRequested(previousState);
        delete previousState;
    }
    else {
        qDebug() << "Невозможно вернуть";
    }
}

bool States::hasStates() {
    return !stack.isEmpty();
}

Estate* States::getActualData() {
    return actualData;
}

void States::add(Estate *value) {
    stack.push(value);
}
