#include "estate.h"

Estate::Estate(QObject *parent)
    : QObject(parent),
      age(0),
      area(0),
      residents(0),
      months(0),
      type(ECONOM),
      owner("")
{}

Estate::Estate(int age, int area, int residents, int months, EstateType type, const QString& owner, QObject *parent)
    : QObject(parent),
      age(age),
      area(area),
      residents(residents),
      months(months),
      type(type),
      owner(owner)
{}

Estate::Estate(const Estate &other)
    : QObject(other.parent()),
      age(other.age),
      area(other.area),
      residents(other.residents),
      months(other.months),
      type(other.type),
      owner(other.owner)
{

}

EstateType Estate::getType() const {
    return type;
}

int Estate::getAge() const {
    return age;
}

int Estate::getArea() const {
    return area;
}

int Estate::getResidents() const {
    return residents;
}

int Estate::getMonths() const {
    return months;
}

QString Estate::getOwner() const {
    return owner;
}
