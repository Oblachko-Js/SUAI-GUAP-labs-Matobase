#include <QDebug>
#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget),
    info(this)
{
    ui->setupUi(this);
    ui->pushButton_Undo->setEnabled(false);
    connect(ui->pushButton_Calc, SIGNAL(pressed()), this, SLOT(btnCalcPressed()));
    connect(ui->pushButton_Undo, SIGNAL(pressed()), this, SLOT(btnUndoPressed()));
    connect(&info, &States::fillFormRequested, this, &Widget::fillForm);

    connect(ui->lineEdit_owner, &QLineEdit::textChanged, this, &Widget::resetCostLabel);
    connect(ui->comboBox_estateType, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, &Widget::resetCostLabel);
    connect(ui->comboBox_period, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, &Widget::resetCostLabel);
    connect(ui->lineEdit_residents, &QLineEdit::textChanged, this, &Widget::resetCostLabel);
    connect(ui->lineEdit_area, &QLineEdit::textChanged, this, &Widget::resetCostLabel);
    connect(ui->lineEdit_age, &QLineEdit::textChanged, this, &Widget::resetCostLabel);

    QIntValidator *positiveIntValidator = new QIntValidator(1, INT_MAX, this);
    ui->lineEdit_age->setValidator(positiveIntValidator);
    ui->lineEdit_residents->setValidator(positiveIntValidator);
    ui->lineEdit_area->setValidator(positiveIntValidator);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::resetCostLabel() {
    ui->label_cost->setText("Стоимость страхового взноса: ...");
}

void Widget::update()
{
    auto value = info.getActualData();
    if(value != nullptr){
        fillForm(value);
    }
    ui->pushButton_Undo->setEnabled(info.hasStates());
    value = nullptr;
}

void Widget::btnCalcPressed()
{
    processForm();
}

void Widget::processForm()
{
    int age = ui->lineEdit_age->text().toInt();
    int area = ui->lineEdit_area->text().toInt();
    int residents = ui->lineEdit_residents->text().toInt();
    int months = ui->comboBox_period->currentText().toInt();
    EstateType type;
    QString estateTypeText = ui->comboBox_estateType->currentText();

    if (estateTypeText == "Квартира эконом-класса") {
        type = ECONOM;
    } else if (estateTypeText == "Роскошная квартира") {
        type = LUXURIOUS;
    } else if (estateTypeText == "Таунхаус") {
        type = TOWN_HOUSE;
    } else if (estateTypeText == "Коттедж") {
        type = COTTAGE;
    } else {
        type = ECONOM;
    }

    QString owner = ui->lineEdit_owner->text();

    ConcreteEstate *value = new ConcreteEstate(age, area, residents, months, type, owner);

    showCost(value);

    info.add(value);

    qDebug() << "Added value to info:" << value;

    ui->pushButton_Undo->setEnabled(true);
}

void Widget::btnUndoPressed()
{
    info.undo();
}

void Widget::fillForm(Estate *value)
{
    ui->lineEdit_age->setText(QString::number(value->getAge()));
    ui->lineEdit_area->setText(QString::number(value->getArea()));
    ui->lineEdit_residents->setText(QString::number(value->getResidents()));
    ui->comboBox_period->setCurrentText(QString::number(value->getMonths()));
    ui->comboBox_estateType->setCurrentIndex(static_cast<int>(value->getType()));
    ui->lineEdit_owner->setText(value->getOwner());
}

void Widget::showCost(Estate *value)
{
    int cost = CalculationFacade::getCost(value);

    ui->label_cost->setText("Стоимость страхового взноса: " + QString::number(cost));
}
