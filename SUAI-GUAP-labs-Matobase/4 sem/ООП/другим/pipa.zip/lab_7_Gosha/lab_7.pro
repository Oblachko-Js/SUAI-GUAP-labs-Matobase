#-------------------------------------------------
#
# Project created by QtCreator 2024-03-20T19:06:02
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = lab_7
TEMPLATE = app


SOURCES += main.cpp\
        widget.cpp \
    townhousecalc.cpp \
    states.cpp \
    luxuriousapartmentcalc.cpp \
    estate.cpp \
    cottagecalc.cpp \
    calculationfacade.cpp \
    apartmentcalc.cpp \
    abstractcalc.cpp \
    calcfactory.cpp

HEADERS  += widget.h \
    townhousecalc.h \
    states.h \
    luxuriousapartmentcalc.h \
    estate.h \
    cottagecalc.h \
    calculationfacade.h \
    abstractcalc.h \
    calcfactory.h \
    apartmentcalc.h

FORMS    += widget.ui

CONFIG += C++11
