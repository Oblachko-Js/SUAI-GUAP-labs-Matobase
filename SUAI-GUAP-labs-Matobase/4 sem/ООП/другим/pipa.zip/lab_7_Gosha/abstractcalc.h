#ifndef ABSTRACTCALC_H
#define ABSTRACTCALC_H
#include "estate.h"

class AbstractCalc {
public:
    AbstractCalc(); // объявление конструктора
    virtual ~AbstractCalc(); // объявление деструктора

    virtual int calculateCost(Estate *value) = 0;
};

#endif
