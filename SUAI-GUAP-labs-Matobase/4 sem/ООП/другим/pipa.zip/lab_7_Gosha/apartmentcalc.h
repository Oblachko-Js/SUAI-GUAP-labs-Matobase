#ifndef APARTMENTCALC_H
#define APARTMENTCALC_H

#include "abstractcalc.h"
#include <estate.h>

class ApartmentCalc : public AbstractCalc {
public:
    int calculateCost(Estate *estate) override;
};

#endif
