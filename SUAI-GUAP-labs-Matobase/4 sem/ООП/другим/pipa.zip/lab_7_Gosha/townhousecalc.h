#ifndef TOWNHOUSECALC_H
#define TOWNHOUSECALC_H

#include "abstractcalc.h"
#include <estate.h>

class TownhouseCalc : public AbstractCalc {
public:
    int calculateCost(Estate *estate) override;
};

#endif
