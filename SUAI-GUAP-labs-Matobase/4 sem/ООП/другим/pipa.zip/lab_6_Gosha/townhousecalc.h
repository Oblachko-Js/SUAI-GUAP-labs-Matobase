// townhousecalc.h
#ifndef TOWNHOUSECALC_H
#define TOWNHOUSECALC_H

#include <estate.h>

class TownhouseCalc {
public:
    static int calculateCost(Estate *estate);
};

#endif // TOWNHOUSECALC_H
