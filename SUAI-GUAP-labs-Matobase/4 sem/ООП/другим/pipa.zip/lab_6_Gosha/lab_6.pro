#-------------------------------------------------
#
# Project created by QtCreator 2024-03-20T11:02:16
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = lab_6
TEMPLATE = app


SOURCES += main.cpp\
        widget.cpp \
    estate.cpp \
    states.cpp \
    calculationfacade.cpp \
    apartmentcalc.cpp \
    luxuriousapartmentcalc.cpp \
    townhousecalc.cpp \
    cottagecalc.cpp

HEADERS  += widget.h \
    estate.h \
    states.h \
    calculationfacade.h \
    apartmentcalc.h \
    luxuriousapartmentcalc.h \
    townhousecalc.h \
    cottagecalc.h

FORMS    += widget.ui

CONFIG += C++11
