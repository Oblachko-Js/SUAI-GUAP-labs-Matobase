// apartmentcalc.h
#ifndef APARTMENTCALC_H
#define APARTMENTCALC_H

#include <estate.h>

class ApartmentCalc {
public:
    static int calculateCost(Estate *estate);
};

#endif // APARTMENTCALC_H
