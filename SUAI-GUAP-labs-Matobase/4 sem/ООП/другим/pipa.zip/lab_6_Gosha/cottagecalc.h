// cottagecalc.h
#ifndef COTTAGECALC_H
#define COTTAGECALC_H

#include <estate.h>

class CottageCalc {
public:
    static int calculateCost(Estate *estate);
};

#endif // COTTAGECALC_H
