// estate.h
#ifndef ESTATE_H
#define ESTATE_H

#include <QObject>
#include <QString>
#include <QMap>

enum EstateType {
    ECONOM,
    LUXURIOUS,
    TOWN_HOUSE,
    COTTAGE
};

enum PeriodType {
    SIX_MONTHS,
    ONE_YEAR,
    EIGHTEEN_MONTHS
};

extern const QMap<QString, EstateType> estateTypeMap;
extern const QMap<QString, PeriodType> periodTypeMap;

class Estate : public QObject {
    Q_OBJECT

public:
    explicit Estate(QObject *parent = nullptr);
    Estate(int age, int area, int residents, int months, EstateType type, const QString& owner, QObject *parent = nullptr);
    EstateType getType() const;
    int getAge() const;
    int getArea() const;
    int getResidents() const;
    int getMonths() const;
    QString getOwner() const;
    virtual void fillForm() {}
    virtual void showCost() {}

    // Конструктор копирования
    Estate(const Estate &other);

private:
    int age;
    int area;
    int residents;
    int months;
    EstateType type;
    QString owner;
};

// Добавляем объявление ConcreteEstate
class ConcreteEstate : public Estate {
public:
    ConcreteEstate(int age, int area, int residents, int months, EstateType type, const QString& owner, QObject *parent = nullptr)
        : Estate(age, area, residents, months, type, owner, parent) {}
};

#endif // ESTATE_H
