// apartmentcalc.cpp
#include "apartmentcalc.h"

int ApartmentCalc::calculateCost(Estate *estate) {
    // Рассчитываем стоимость квартиры, например, по формуле:
    // стоимость = площадь * цена_за_квадратный_метр * период проживания
    double area = estate->getArea(); // Получаем площадь из объекта Estate
    double period = estate->getMonths(); // Получаем период проживания из объекта Estate
    double pricePerSquareMeter = 200.0; // Пример цены за квадратный метр
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
