// luxuriousapartmentcalc.h
#ifndef LUXURIOUSAPARTMENTCALC_H
#define LUXURIOUSAPARTMENTCALC_H

#include <estate.h>

class LuxuriousApartmentCalc {
public:
    static int calculateCost(Estate *estate);
};

#endif // LUXURIOUSAPARTMENTCALC_H
