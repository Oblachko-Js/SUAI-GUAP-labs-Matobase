// Листинг файла states.h
#ifndef STATES_H
#define STATES_H

#include <QObject>
#include <QStack>
#include "estate.h"

class States : public QObject {
    Q_OBJECT

public:
    explicit States(QObject *parent = nullptr);
    ~States();
    void undo();
    bool hasStates();
    Estate* getActualData();
    void add(Estate *value);

signals:
    void stateChanged(const Estate &state);
    void fillFormRequested(Estate *state); // Добавляем сигнал для запроса заполнения формы

private:
    QStack<Estate *> stack;
    Estate *actualData;
};

#endif // STATES_H
