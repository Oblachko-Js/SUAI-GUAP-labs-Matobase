// widget.h
#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <states.h>
#include <estate.h>
#include <calculationfacade.h>

namespace Ui {
class Widget;
}

class Widget : public QWidget {
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

public slots:
    void update();

private slots:
    void resetCostLabel();
    void btnCalcPressed();
    void btnUndoPressed();

private:
    void processForm();
    void fillForm(Estate *value);
    void showCost(Estate *value);

private:
    Ui::Widget *ui;
    States info;
};

#endif // WIDGET_H
