// luxuriousapartmentcalc.cpp
#include "luxuriousapartmentcalc.h"

int LuxuriousApartmentCalc::calculateCost(Estate *estate) {
    // Рассчитываем стоимость элитной квартиры, например, по формуле:
    // стоимость = площадь * цена_за_квадратный_метр * период проживания
    double area = estate->getArea(); // Получаем площадь из объекта Estate
    double pricePerSquareMeter = 1000.0; // Пример цены за квадратный метр
    double period = estate->getMonths(); // Получаем период проживания из объекта Estate
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
