// Листинг файла states.cpp
#include "states.h"
#include <QDebug>

States::States(QObject *parent) : QObject(parent) {
    actualData = nullptr;
}

States::~States() {
    if (actualData) {
        delete actualData;
        actualData = nullptr;
    }
    qDeleteAll(stack);
    stack.clear();
}

void States::undo() {
    qDebug() << "Undo function called"; // Отладочный вывод
    if (!stack.isEmpty()) {
        Estate *previousState = stack.pop();
        emit stateChanged(*previousState); // Отправляем состояние через сигнал
        emit fillFormRequested(previousState); // Запрос на заполнение формы данными из предыдущего состояния
        delete previousState; // Не забываем освободить память
    }
    else {
        qDebug() << "Невозможно вернуть"; // Отладочный вывод
    }
}

bool States::hasStates() {
    return !stack.isEmpty();
}

Estate* States::getActualData() {
    return actualData;
}

void States::add(Estate *value) {
    stack.push(value); // Здесь просто добавляем указатель на объект
}
