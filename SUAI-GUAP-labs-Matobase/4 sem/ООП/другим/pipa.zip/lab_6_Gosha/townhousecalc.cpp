// townhousecalc.cpp
#include "townhousecalc.h"

int TownhouseCalc::calculateCost(Estate *estate) {
    // Рассчитываем стоимость таунхауса, например, по формуле:
    // стоимость = площадь * цена_за_квадратный_метр * период проживания
    double area = estate->getArea();
    double pricePerSquareMeter = 390;
    double period = estate->getMonths(); // Получаем период проживания из объекта Estate
    int cost = static_cast<int>(area * pricePerSquareMeter * period);
    return cost;
}
