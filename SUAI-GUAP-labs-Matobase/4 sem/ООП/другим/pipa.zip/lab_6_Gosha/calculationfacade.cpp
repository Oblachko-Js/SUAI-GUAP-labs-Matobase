#include "calculationfacade.h"
#include "apartmentcalc.h"
#include "luxuriousapartmentcalc.h"
#include "townhousecalc.h"
#include "cottagecalc.h"

CalculationFacade::CalculationFacade(QObject *parent) : QObject(parent) {
}

int CalculationFacade::getCost(Estate *value) {
    int cost;
    switch (value->getType()) {
        case ECONOM:
            cost = ApartmentCalc::calculateCost(value);
            break;
        case LUXURIOUS:
            cost = LuxuriousApartmentCalc::calculateCost(value);
            break;
        case TOWN_HOUSE:
            cost = TownhouseCalc::calculateCost(value);
            break;
        case COTTAGE:
            cost = CottageCalc::calculateCost(value);
            break;
        default:
            cost = -1; // Либо возвращать значение по умолчанию, если тип недвижимости не определен
            break;
    }
    return cost;
}
