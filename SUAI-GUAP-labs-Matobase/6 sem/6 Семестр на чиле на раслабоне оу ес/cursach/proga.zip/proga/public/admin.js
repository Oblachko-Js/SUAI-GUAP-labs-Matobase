// Проверка авторизации
async function checkAuth() {
  const response = await fetch("/auth/check", {
    method: "GET",
    credentials: "include",
  });

  if (!response.ok) {
    window.location.href = "/";
  }
}

// Загрузка данных
async function loadData() {
  await checkAuth();

  try {
    const usersResponse = await fetch("/admin/users", {
      credentials: "include",
    });
    const users = await usersResponse.json();
    renderTable(
      "usersTable",
      users,
      (user) => `
        <tr>
          <td>${user.id}</td>
          <td>${user.login}</td>
          <td>${user.email}</td>
          <td>${user.is_online ? "Онлайн" : "Офлайн"}</td>
        </tr>
      `
    );

    const tasksResponse = await fetch("/admin/tasks", {
      credentials: "include",
    });
    const tasks = await tasksResponse.json();
    renderTable(
      "tasksTable",
      tasks,
      (task) => `
        <tr>
          <td>${task.id}</td>
          <td>${task.name}</td>
          <td>${task.completed ? "Выполнено" : "Не выполнено"}</td>
        </tr>
      `
    );

    const habitsResponse = await fetch("/admin/habits", {
      credentials: "include",
    });
    const habits = await habitsResponse.json();
    renderTable(
      "habitsTable",
      habits,
      (habit) => `
        <tr>
          <td>${habit.id}</td>
          <td>${habit.name}</td>
          <td>${habit.status}</td>
        </tr>
      `
    );
  } catch (err) {
    console.error("Ошибка при загрузке данных:", err);
  }
}

// Функция для отображения данных в таблице
function renderTable(tableId, data, rowTemplate) {
  const tableBody = document.querySelector(`#${tableId} tbody`);
  tableBody.innerHTML = data.map(rowTemplate).join("");
}

// Загрузка данных при загрузке страницы
window.onload = loadData;
