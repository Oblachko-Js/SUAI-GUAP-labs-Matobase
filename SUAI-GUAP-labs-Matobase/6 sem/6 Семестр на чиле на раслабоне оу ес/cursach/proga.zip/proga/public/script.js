document
  .getElementById("registerForm")
  .addEventListener("submit", async (e) => {
    e.preventDefault();
    const login = document.getElementById("registerLogin").value;
    const email = document.getElementById("registerEmail").value;
    const password = document.getElementById("registerPassword").value;

    const response = await fetch("http://localhost:3000/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ login, email, password }),
    });

    const data = await response.json();
    if (response.ok) {
      showMessage("Регистрация успешна!");
    } else {
      showMessage(data.error || "Ошибка при регистрации");
    }
  });

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const emailOrLogin = document.getElementById("loginEmail").value; // Поле может содержать email или логин
  const password = document.getElementById("loginPassword").value;

  const response = await fetch("http://localhost:3000/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email: emailOrLogin, password }), // Передаем значение как email
  });

  const data = await response.json();
  if (response.ok) {
    showMessage("Вход выполнен успешно!");
    // Перенаправление на страницу в зависимости от роли
    if (data.isAdmin) {
      window.location.href = "/admin.html";
    } else {
      window.location.href = "/user.html";
    }
  } else {
    showMessage(data.error || "Ошибка при входе");
  }
});

function showMessage(message) {
  const messageDiv = document.getElementById("message");
  messageDiv.textContent = message;
  setTimeout(() => {
    messageDiv.textContent = "";
  }, 3000);
}
