const express = require("express");
const { requireAdmin } = require("../middleware/authMiddleware");
const db = require("../db");
const router = express.Router();

// Получить всех пользователей
router.get("/users", requireAdmin, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT id, login, email, state, 
             (last_active > NOW() - INTERVAL '5 minutes') AS is_online
      FROM users
    `);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка при получении пользователей" });
  }
});

// Получить все задачи
router.get("/tasks", requireAdmin, async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM tasks");
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка при получении задач" });
  }
});

// Получить все привычки
router.get("/habits", requireAdmin, async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM habits");
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка при получении привычек" });
  }
});

module.exports = router;
