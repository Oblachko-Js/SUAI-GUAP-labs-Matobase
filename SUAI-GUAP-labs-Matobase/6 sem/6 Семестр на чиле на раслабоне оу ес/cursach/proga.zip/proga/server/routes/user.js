const express = require("express");
const db = require("../db");
const router = express.Router();

// Создание или обновление персонажа
router.post("/character", async (req, res) => {
  const { userId, name, health, mana, experience, imageUrl } = req.body;
  try {
    // Проверяем, есть ли уже персонаж у пользователя
    const existingCharacter = await db.query(
      "SELECT * FROM characters WHERE user_id = $1",
      [userId]
    );

    if (existingCharacter.rows.length > 0) {
      // Если персонаж уже есть, обновляем его
      const result = await db.query(
        "UPDATE characters SET name = $1, health = $2, mana = $3, experience = $4, image_url = $5 WHERE user_id = $6 RETURNING *",
        [name, health, mana, experience, imageUrl, userId]
      );
      res.status(200).json(result.rows[0]);
    } else {
      // Если персонажа нет, создаем нового
      const result = await db.query(
        "INSERT INTO characters (user_id, name, health, mana, experience, image_url) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
        [userId, name, health, mana, experience, imageUrl]
      );
      res.status(201).json(result.rows[0]);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка при создании/обновлении персонажа" });
  }
});

// Получение персонажа
router.get("/character/:userId", async (req, res) => {
  const { userId } = req.params;
  try {
    const result = await db.query(
      "SELECT * FROM characters WHERE user_id = $1",
      [userId]
    );
    if (result.rows.length > 0) {
      res.status(200).json(result.rows[0]);
    } else {
      res.status(404).json({ error: "Персонаж не найден" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка при получении персонажа" });
  }
});

module.exports = router;
