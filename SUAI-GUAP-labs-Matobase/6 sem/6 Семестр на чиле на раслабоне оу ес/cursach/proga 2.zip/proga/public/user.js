// Получаем элементы DOM
const characterInfo = document.getElementById("characterInfo");
const createCharacterBtn = document.getElementById("createCharacterBtn");
const characterForm = document.getElementById("characterForm");
const characterFormFields = document.getElementById("characterFormFields");
const cancelCharacterBtn = document.getElementById("cancelCharacterBtn");

// Получаем элементы DOM для задач и привычек
const tasksList = document.getElementById("tasksList");
const createTaskBtn = document.getElementById("createTaskBtn");
const taskForm = document.getElementById("taskForm");
const taskFormFields = document.getElementById("taskFormFields");

// Функция для загрузки данных о персонаже
async function loadCharacter() {
  try {
    const response = await fetch("/user/character", {
      method: "GET",
      credentials: "include", // Передаём куки сессии
    });
    const data = await response.json();

    if (response.ok) {
      // Отображаем информацию о персонаже
      characterInfo.innerHTML = `
        <p><strong>Имя:</strong> ${data.name}</p>
        <p><strong>Уровень:</strong> ${data.level}</p>
        <p><strong>Здоровье:</strong> ${data.health}</p>
        <p><strong>Мана:</strong> ${data.mana}</p>
        <p><strong>Опыт:</strong> ${data.experience}</p>
        <p><strong>Золото:</strong> ${data.gold}</p>
      `;
    } else {
      characterInfo.innerHTML = "<p>Персонаж не найден. Создайте нового!</p>";
    }
  } catch (err) {
    console.error("Ошибка при загрузке персонажа:", err);
    characterInfo.innerHTML = "<p>Ошибка при загрузке персонажа.</p>";
  }
}

// Функция для создания/обновления персонажа
async function saveCharacter(event) {
  event.preventDefault();

  const name = document.getElementById("characterName").value;
  const level = document.getElementById("characterLevel").value;
  const health = document.getElementById("characterHealth").value;
  const mana = document.getElementById("characterMana").value;
  const experience = document.getElementById("characterExperience").value;
  const gold = document.getElementById("characterGold").value;

  try {
    const response = await fetch("/user/character", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include", // Передаем куки сессии
      body: JSON.stringify({ name, level, health, mana, experience, gold }),
    });

    if (response.ok) {
      alert("Персонаж успешно сохранен!");
      characterForm.style.display = "none";
      loadCharacter(); // Перезагружаем данные о персонаже
    } else {
      alert("Ошибка при сохранении персонажа.");
    }
  } catch (err) {
    console.error("Ошибка при сохранении персонажа:", err);
  }
}

// Показываем форму для создания/обновления персонажа
createCharacterBtn.addEventListener("click", () => {
  characterForm.style.display = "block";
});

// Скрываем форму при отмене
cancelCharacterBtn.addEventListener("click", () => {
  characterForm.style.display = "none";
});

// Обработка отправки формы
characterFormFields.addEventListener("submit", saveCharacter);

// Функция загрузки задач
async function loadTasks() {
  try {
    const response = await fetch("/tasks", {
      method: "GET",
      credentials: "include",
    });
    const tasks = await response.json();

    tasksList.innerHTML = ""; // Очищаем список перед обновлением

    tasks.forEach((task) => {
      const taskItem = document.createElement("div");
      taskItem.classList.add("task-item");
      if (task.completed) taskItem.classList.add("completed");

      taskItem.innerHTML = `
          <h3>${task.name}</h3>
          <p>${task.description}</p>
          <p>Сложность: ${task.difficulty}</p>
          <p>Срок: ${new Date(task.due_date).toLocaleDateString()}</p>
          <button onclick="toggleHabits(${task.id})" id="toggle-habits-${
        task.id
      }">
            Показать привычки
          </button>
          <div class="habits-list" id="habits-${
            task.id
          }" style="display: none;"></div>
          <button onclick="addHabit(${task.id})">Добавить привычку</button>
          <button onclick="deleteTask(${
            task.id
          })" class="delete-task-btn">Удалить задачу</button>
        `;

      tasksList.appendChild(taskItem);
    });
  } catch (err) {
    console.error("Ошибка при загрузке задач:", err);
  }
}

async function toggleHabits(taskId) {
  const habitsList = document.getElementById(`habits-${taskId}`);
  const toggleButton = document.getElementById(`toggle-habits-${taskId}`);

  if (habitsList.style.display === "none") {
    // Разворачиваем список, если он скрыт
    habitsList.style.display = "block";
    toggleButton.textContent = "Скрыть привычки";
    await loadHabits(taskId); // Загружаем привычки
  } else {
    // Сворачиваем список, если он уже открыт
    habitsList.style.display = "none";
    toggleButton.textContent = "Показать привычки";
  }
}

// Функция загрузки привычек для задачи
async function loadHabits(taskId) {
  try {
    const response = await fetch(`/tasks/${taskId}/habits`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Ошибка ${response.status}: ${response.statusText}`);
    }

    const habits = await response.json();
    const habitsList = document.getElementById(`habits-${taskId}`);
    habitsList.innerHTML = "";

    if (!habits.length) {
      habitsList.innerHTML = "<p>Нет привычек.</p>";
      return;
    }

    habits.forEach((habit) => {
      const habitItem = document.createElement("div");
      habitItem.classList.add("habit-item");
      if (habit.status === "Выполнено") habitItem.classList.add("completed");

      habitItem.innerHTML = `
          <span><strong>${habit.name}</strong></span>
          <p>${habit.description}</p>
          <input type="checkbox" 
                 ${habit.status === "Выполнено" ? "checked" : ""} 
                 onchange="toggleHabit(${habit.id}, ${taskId}, this.checked)">
          <button onclick="deleteHabit(${
            habit.id
          }, ${taskId})" class="delete-habit-btn">Удалить</button>
        `;

      habitsList.appendChild(habitItem);
    });
  } catch (err) {
    console.error("Ошибка при загрузке привычек:", err);
  }
}

// Функция создания новой задачи
async function createTask(event) {
  event.preventDefault();

  const name = document.getElementById("taskName").value;
  const description = document.getElementById("taskDescription").value;
  const difficulty = document.getElementById("taskDifficulty").value;
  const due_date = document.getElementById("taskDueDate").value;

  try {
    const taskResponse = await fetch("/tasks/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ name, description, difficulty, due_date }),
    });

    if (taskResponse.ok) {
      alert("Задача успешно создана!");
      taskForm.style.display = "none";
      loadTasks();
    } else {
      alert("Ошибка при создании задачи.");
    }
  } catch (err) {
    console.error("Ошибка при создании задачи:", err);
  }
}

// Функция добавления привычки в задачу
async function addHabit(taskId) {
  const habitName = prompt("Введите название привычки:");
  if (!habitName) return;

  const habitDescription = prompt("Введите описание привычки:") || ""; // Описание можно оставить пустым

  try {
    const response = await fetch(`/tasks/${taskId}/habit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        name: habitName,
        description: habitDescription, // Передаём описание привычки
        difficulty: "Средняя",
      }),
    });

    if (!response.ok) {
      throw new Error("Ошибка при создании привычки.");
    }

    alert("Привычка успешно добавлена!");
    loadHabits(taskId); // Обновляем список привычек
  } catch (err) {
    console.error("Ошибка при добавлении привычки:", err);
    alert("Не удалось добавить привычку.");
  }
}

// Функция отметки выполнения привычки
async function toggleHabit(habitId, taskId, isChecked) {
  try {
    await fetch(`/habits/${habitId}`, {
      // Здесь вместо taskId используем habitId
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        status: isChecked ? "Выполнено" : "Не выполнено",
      }),
    });

    loadHabits(taskId); // Перезагружаем привычки после изменения
    checkTaskCompletion(taskId);
  } catch (err) {
    console.error("Ошибка при изменении статуса привычки:", err);
  }
}

// Проверка выполнения всех привычек в задаче
async function checkTaskCompletion(taskId) {
  try {
    const response = await fetch(`/tasks/${taskId}/habits`, {
      method: "GET",
      credentials: "include",
    });

    //console.log("Ответ сервера:", response);

    const habits = await response.json();

    const allCompleted = habits.every((habit) => habit.status === "Выполнено");

    if (allCompleted) {
      await fetch(`/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ completed: true }),
      });

      loadTasks();
    }
  } catch (err) {
    console.error("Ошибка при проверке выполнения задачи:", err);
  }
}

async function deleteTask(taskId) {
  if (!confirm("Вы уверены, что хотите удалить эту задачу?")) return;

  try {
    const response = await fetch(`/tasks/${taskId}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Ошибка при удалении задачи.");

    alert("Задача удалена!");
    loadTasks(); // Перезагрузка списка задач
  } catch (err) {
    console.error("Ошибка при удалении задачи:", err);
    alert("Не удалось удалить задачу.");
  }
}

async function deleteHabit(habitId, taskId) {
  if (!confirm("Вы уверены, что хотите удалить эту привычку?")) return;

  try {
    const response = await fetch(`/habits/${habitId}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Ошибка при удалении привычки.");

    alert("Привычка удалена!");
    loadHabits(taskId); // Перезагрузка списка привычек
  } catch (err) {
    console.error("Ошибка при удалении привычки:", err);
    alert("Не удалось удалить привычку.");
  }
}

// Обработчик отправки формы для задачи
taskFormFields.addEventListener("submit", createTask);

// Показываем форму для создания задачи
createTaskBtn.addEventListener("click", () => {
  taskForm.style.display = "block";
});

// Скрываем форму при нажатии "Отмена"
document.getElementById("cancelTaskBtn").addEventListener("click", () => {
  taskForm.style.display = "none";
});

// Загружаем данные о персонаже и задачи при загрузке страницы
window.onload = function () {
  loadCharacter();
  loadTasks();
};
