const express = require("express");
const { requireAuth } = require("../middleware/authMiddleware");
const db = require("../db");
const router = express.Router();

// Обновление статуса привычки
router.patch("/:id", requireAuth, async (req, res) => {
  const userId = req.session.user.id;
  const { id } = req.params;
  const { status } = req.body;

  //console.log("Обновление привычки с ID:", id); // ЛОГ ДЛЯ ОТЛАДКИ

  try {
    const result = await db.query(
      "UPDATE habits SET status = $1 WHERE id = $2 AND user_id = $3 RETURNING *",
      [status, id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Привычка не найдена" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Ошибка при обновлении привычки:", err);
    res.status(500).json({ error: "Ошибка при обновлении привычки" });
  }
});

// Удаление привычки
router.delete("/:id", requireAuth, async (req, res) => {
  const userId = req.session.user.id;
  const { id } = req.params;

  try {
    const result = await db.query(
      "DELETE FROM habits WHERE id = $1 AND user_id = $2 RETURNING *",
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Привычка не найдена" });
    }

    res.json({ message: "Привычка удалена", deletedHabit: result.rows[0] });
  } catch (err) {
    console.error("Ошибка при удалении привычки:", err);
    res.status(500).json({ error: "Ошибка при удалении привычки" });
  }
});

module.exports = router;
