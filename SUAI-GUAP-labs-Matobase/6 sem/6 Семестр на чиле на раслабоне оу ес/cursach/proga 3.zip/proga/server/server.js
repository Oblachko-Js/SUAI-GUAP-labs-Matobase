const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const cors = require("cors");
const db = require("./db");
const authRoutes = require("./routes/auth");
const adminRoutes = require("./routes/admin");
const userRoutes = require("./routes/user");
const tasksRoutes = require("./routes/tasks");
const habitsRoutes = require("./routes/habits");
const path = require("path");

const app = express();
const port = 3000;

// Настройка сессий
app.use(
  session({
    secret: "your-secret-key", // Секретный ключ для подписи сессии
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Для HTTPS установите true
  })
);

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Подключение к базе данных
db.connect();

// Маршруты
app.use("/auth", authRoutes);
app.use("/admin", adminRoutes);
app.use("/user", userRoutes);
app.use("/tasks", tasksRoutes);
app.use("/habits", habitsRoutes);

// Отдача статических файлов (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, "../public")));

// Защищенный доступ к admin.html
app.get("/admin.html", (req, res) => {
  if (req.session.user && req.session.user.login === "admin") {
    res.sendFile(path.join(__dirname, "../public/admin.html"));
  } else {
    res.status(403).send("Доступ запрещен");
  }
});

// Защищенный доступ к user.html
app.get("/user.html", (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, "../public/user.html"));
  } else {
    res.status(403).send("Доступ запрещен");
  }
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});
